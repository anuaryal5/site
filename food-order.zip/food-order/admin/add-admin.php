<?php include("partials/menu.php"); ?>

<div class="main-content">
	<div class="wrapper">
		<h1> Add Admin</h1>

		<?php 
		if(isset($_SESSION['add']))
		{
			echo $_SESSION['add'];
			unset($_SESSION['add']);
		}
		?>

		<form action="" method="POST">
			<table class="tbl-30">
				<tr>
					<td>Full Name</td>	
					<td><input type="text" name="full_name" placeholder="Enter name"></td>
					
				</tr>
				<tr>
					<td>UserName</td>	
					<td><input type="text" name="user_name" placeholder="Enter username"></td>
					
				</tr>
				<tr><br>
					<td>Password</td>	
					<td><input type="Password" name="password" placeholder="Enter password"></td><br>
					
				</tr>
				<tr>
					<td colspan="2"><br>
						<input type="submit" name="submit" value="Add Admin" class="btn-secondary">
						
					</td>
				</tr>
			</table>
			
		</form>
		
	</div>
	
</div>






<?php include("partials/footer.php"); ?>

<?php 
// process the value from from and save it to datacase
//  check wheather the button is clicked or not

if(isset($_POST['submit']))
{
	//  button clicked
	// echo "button clicked";

	// get data from from
	$full_name =$_POST['full_name'];
	$user_name =$_POST['user_name'];
	$password =md5($_POST['password']);    

	// sql query to save data into database

	$sql = "INSERT INTO tbl_admin SET full_name='$full_name', user_name='$user_name', password= '$password' ";
	
	// execute query and save data into database
	

	$res = mysqli_query($conn ,$sql) or die(mysqli_error($conn)) ;


	// check wheather data (query) is executed or not
	if($res==TRUE)
	{
		// data inserted
		// echo "data inserted";
		// creating session variable to diaplay message
		$_SESSION['add'] = "<div class='success'>Admin added successfully</div>";
		// redirect page to manage admin
		header("location:".SITEURL.'admin/manage-admin.php');
	}else
	{
		// echo "not inseryed";
		// creating session variable to diaplay message
		$_SESSION['add'] = "<div class='error'>Admin added failed</div>";
		// redirect page to add admin
		header("location:".SITEURL.'admin/add-admin.php');
	}



}



?>