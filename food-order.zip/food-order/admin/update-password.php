<?php include("partials/menu.php"); ?>

<div class="main-content">

	<div class="wrapper">
		<h1> Change Password</h1>
		<br> <br>

		<?php
				if(isset($_GET['id']))
				{
					$id =$_GET['id'];
				}

		 ?>

		<form action="" method="POST">
			<table class="tbl-30">
				<tr>
					<td> Current password</td>
					<td> <input type="password" name="current_password" placeholder="OLD PASSWORD" > </td>
				</tr>

				<tr>
					<td> New Password</td>
					<td> <input type="password" name="new_password" placeholder="New Password"></td>

				</tr>

				<tr>
					<td> Conform Password</td>
					<td> <input type="password" name="confirm_password" placeholder="Confirm Password"></td>
				</tr>


				<tr>
					<td colspan="2">
						<input type="hidden" name="id" value="<?php echo $id?>">
						<input type="submit" name="submit" value="Change Password" class="btn-secondary">
					</td>
				</tr>


			</table>	

		</form>
		
	</div>
	
</div>

<?php 
		// check whether submit is click or not
		if(isset($_POST['submit']))
		 {
			// echo "Button clicked";
			
			// Get all the values from form to update

			$id = $_POST['id'];
			$current_password =md5($_POST['current_password']);
			$new_password = md5($_POST['new_password']);
			$confirm_password =md5($_POST['confirm_password']);


			// sal query to update admin

			$sql = "SELECT *FROM tbl_admin WHERE id=$id AND password='$current_password' ";

			// executing query
			$res = mysqli_query($conn ,$sql) or die(mysqli_error($conn)) ;

			// check whether query execute

				if($res==TRUE)
				{
					// check wheather data is available or not
					$count =mysqli_num_rows($res);

					if($count==1)
					{
						// user exist and password can rechange

						// check new and confirm password match or not
						if($new_password==$confirm_password)
						{
							// update
							$sql2 = "UPDATE tbl_admin SET password='$new_password' WHERE id=$id";
							$res2 = mysqli_query($conn,$sql2);
							// check query execute or not

							if($res2==TRUE)
							{
								// display
								// redirect to manage admin
									$_SESSION['change-pwd']= " <div class='success'> Password Change</div> ";
										// redirect
						
										header('location:'.SITEURL.'admin/manage-admin.php');
							}
							else
							{
								// display error
								$_SESSION['change-pwd']= " <div class='error'> Error Password Change</div> ";
										// redirect
						
										header('location:'.SITEURL.'admin/manage-admin.php');
							}

						}
						else
						{
							// redirect to manage admin
							$_SESSION['pwd-not-match']= " <div class='error'> Password not match </div> ";
						// redirect
						
						header('location:'.SITEURL.'admin/manage-admin.php');
						}

					}
					else
					{
						// user not exist set message and redirect
						$_SESSION['user-not-found']= " <div class='error'> USER not found </div> ";
						// redirect
						
						header('location:'.SITEURL.'admin/manage-admin.php');
					}
					
				}
	
			}

?>

