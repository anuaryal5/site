<?php

// to include constrants.php file
		include('../config/constants.php');


// Get the id of admin to be deleted

	$id= $_GET['id'];


//create sql query to delete admin
	$sql ="DELETE FROM tbl_admin WHERE id=$id";

// to execute query
	$res=mysqli_query($conn,$sql);

// to check whether query works or not

	if($res==TRUE)
	{
		// query executed
		// echo "Admin Deleted";

		// create session variable to display message

		$_SESSION['delete']= "<div class='success'>Admin deleted </div>";
		// redirect to manage admin page
		header('location:'.SITEURL.'admin/manage-admin.php');
	}
	else
	{
		// failed query
		// echo "failed to Delete";
		$_SESSION['delete'] ="<div class='error'> FAiled to delete Admin Try again </div>";
		header('location:'.SITEURL.'admin/manage-admin.php');
	}



 //redirect to manage admin page with message (either success and error) 


?>