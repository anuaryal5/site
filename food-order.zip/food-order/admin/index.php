<?php include("partials/menu.php") ?>

         <!-- main content starts -->
         <div class="main-content">
             <div class="wrapper">
                 <h1> Dashboard </h1>
                 <br>

                 <?php
                 
                    if(isset($_SESSION['login']))
                        {
                          echo $_SESSION['login'];
                          unset($_SESSION['login']);
                        }


                  ?>
                  <br>


                 <div class="col-4 text-centre">
                    <h1>5</h1> <br>
                    Categories     
                </div>
                <div class="col-4 text-centre">
                    <h1>5</h1> <br>
                    Categories     
                </div>
                <div class="col-4 text-centre">
                    <h1>5</h1> <br>
                    Categories     
                </div>
                <div class="col-4 text-centre">
                    <h1>5</h1> <br>
                    Categories     
                </div>
                <div class="clearfix"> </div>
             </div>
        </div>
         <!-- main contents ends -->

         <?php include("partials/footer.php") ?>