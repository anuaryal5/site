<?php 

	// include constrants.php
	// include('../config/constants.php');
	include('../config/constants.php');
	// destroy the session 
	session_destroy(); //unset sessiom_user

	// redirect to login page
	
	header('location:'.SITEURL.'admin/login.php');






?>