<?php include("partials/menu.php") ?>

         <!-- main content starts -->
         <div class="main-content">
             <div class="wrapper">
                 <h1> Manage food </h1>
                 <br>
                 <!-- button to add admin -->
                 <a href="#" class="btn-primary"> Add Food </a>
                 <br> <br>


                 <table class="tbl-full">
                 	<tr>
                 		<th>S.no</th>
                 		<th>Full Name</th>
                 		<th>Username</th>
                 		<th>Actions</th>
                 	
                 	</tr>
                 	<tr>
                 		<td>1.</td>
                 		<td>Anu Aryal</td>
                 		<td>anu_aryal05</td>
                 		<td>
                 			<a href= "#" class="btn-secondary"> update admin</a>
                 			<a href="#" class="btn-danger"> Delete Admin </a>
                 		</td>
                 	</tr>
                 	<tr>
                 		<td>2.</td>
                 		<td>Anu Aryal</td>
                 		<td>anu_aryal05</td>
                 		<td>
                 			<a href= "#" class="btn-secondary"> update admin</a>
                 			<a href="#" class="btn-danger"> Delete Admin </a>
                 		</td>
                 	</tr>
                 	<tr>
                 		<td>3.</td>
                 		<td>Anu Aryal</td>
                 		<td>anu_aryal05</td>
                 		<td>
                 			<a href= "#" class="btn-secondary"> update admin</a>
                 			<a href="#" class="btn-danger"> Delete Admin </a>
                 		</td>
                 	</tr>
                 </table>

                
             </div>
        </div>
         <!-- main contents ends -->

         <?php include("partials/footer.php") ?>