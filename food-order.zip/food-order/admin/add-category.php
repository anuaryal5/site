<?php include('partials/menu.php'); ?>

<div class="main-content">
	<div class="wrapper">
		<h1> Add category		
		</h1>
		<br> <br>
		<!-- add category for start -->

		<!-- add category for stop -->
		
	</div>
	

</div>




<?php include('partials/footer.php'); ?>